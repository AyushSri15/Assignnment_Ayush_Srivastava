import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { PostdataService } from '../TicketService/postdata.service';
import { TicketserviceService } from '../TicketService/ticketservice.service';
import { UserData, UserColumns } from '../Utilites/userData';
// import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  displayedColumns: string[] = UserColumns.map((col) => col.key);
  columnsSchema: any = UserColumns;
  dataSource = new MatTableDataSource<UserData>();
  currSeats: number = 0;
  movieUserData: any;
  movieId: string = '';
  userId: string = '';
  index: number = 0;
  seats: any;
  sendObj: any;


  constructor(
    private postdataobj: PostdataService,
    private moivedataobj: TicketserviceService
  ) {}

  ngOnInit(): void {
    this.postdataobj.getUserData().subscribe((data: any) => {
      this.dataSource.data = data;
      console.log(this.dataSource.data);
    });
  }

  doneChange(event1: any) {
    console.log(event1);
    this.dataSource.data[parseInt(this.userId) - 1].ticketsavl =
      this.dataSource.data[parseInt(this.userId) - 1].seats[this.index] +
      this.currSeats -
      event1.noOfTicket;
    console.log(
      this.dataSource.data[parseInt(this.userId) - 1].seats[this.index]
    );
    console.log(this.currSeats);
    console.log(event1.noOfTicket);
    console.log(event1.ticketsavl);
    this.dataSource.data[parseInt(this.userId) - 1].seats[this.index] =
      this.dataSource.data[parseInt(this.userId) - 1].ticketsavl;
    this.dataSource.data[parseInt(this.userId) - 1].totalprice = this.dataSource.data[parseInt(this.userId) - 1].singleprice * event1.noOfTicket;
    console.log(this.dataSource.data[parseInt(this.userId) - 1].totalprice);
    this.sendObj = {
      noOfTicket: event1.noOfTicket,
      ticketsavl: this.dataSource.data[parseInt(this.userId) - 1].ticketsavl,
      seats: this.dataSource.data[parseInt(this.userId) - 1].seats,
      "totalprice":this.dataSource.data[parseInt(this.userId) - 1].totalprice
    };
    this.postdataobj
      .putUserData(this.userId, this.sendObj)
      .subscribe((data: any) => {
        console.log(data);
      });
    this.moivedataobj
      .updatedata(this.sendObj.seats, this.movieId)
      .subscribe((data: any) => {
        console.log(data);
      });
  }

  valueChange(event: any) {
    this.currSeats = event.noOfTicket;
    console.log(this.currSeats);
    this.userId = event.id;
    console.log(this.userId);
    this.movieId = event.moiveid;
    console.log(this.movieId);
    this.index = event.timingIndex;
    console.log(this.index);
  }
}
