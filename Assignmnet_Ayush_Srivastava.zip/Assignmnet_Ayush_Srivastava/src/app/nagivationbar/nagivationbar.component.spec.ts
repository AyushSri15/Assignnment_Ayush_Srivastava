import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NagivationbarComponent } from './nagivationbar.component';

describe('NagivationbarComponent', () => {
  let component: NagivationbarComponent;
  let fixture: ComponentFixture<NagivationbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NagivationbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NagivationbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
