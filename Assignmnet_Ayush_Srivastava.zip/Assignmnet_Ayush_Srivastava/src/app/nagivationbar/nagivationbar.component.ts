import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nagivationbar',
  templateUrl: './nagivationbar.component.html',
  styleUrls: ['./nagivationbar.component.css']
})
export class NagivationbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
