import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TicketData } from '../Utilites/TicketData';

@Component({
  selector: 'app-seatbooking',
  templateUrl: './seatbooking.component.html',
  styleUrls: ['./seatbooking.component.css']
})
export class SeatbookingComponent implements OnInit {

  product:any;
  data:any;


  nameData:any;
  emailData:any;
  phonenoData:string='';
  noOfTicketData:number=0;
  totalticketData:number=0;
  showTimingData:number=-1;
  dateData:any;
  priceData:number=0;


  dataForm=new TicketData



  constructor(private object:Router) {
    this.product=this.object.getCurrentNavigation()?.extras.state;
    this.data=this.product.data
   }

  ngOnInit(): void {
  }

  onChange(event:any){
    this.showTimingData=parseInt(event.target.value);
    this.totalticketData=this.data.Seats[this.showTimingData];
    this.priceData=this.data.Price[this.showTimingData];
    this.totalticketData=this.totalticketData - this.noOfTicketData;
  }


  checker(): boolean{
    if(this.showTimingData == -1)
    return false;
    else return true;
  }



  datacopying(){
    this.dataForm.moiveid=this.data.id;
    this.dataForm.moiveName=this.data.Movie_name;
    this.dataForm.name=this.nameData;
    this.dataForm.email=this.emailData;
    this.dataForm.phoneno=this.phonenoData;
    this.dataForm.noOfTicket=this.noOfTicketData;
    this.dataForm.timingIndex=this.showTimingData;
    this.dataForm.showTiming=this.data.Timings[this.showTimingData];
    this.dataForm.date=this.dateData;
    this.dataForm.totalTicket=this.dataForm.seats[this.showTimingData]-this.noOfTicketData;
    this.dataForm.ticketsavl=this.totalticketData-this.noOfTicketData;
    this.dataForm.singleprice=this.data.Price[this.showTimingData];
    this.dataForm.totalprice=this.data.Price[this.showTimingData] * this.noOfTicketData;
    this.dataForm.imageUrl=this.data.Image;
    this.dataForm.timing=this.data.Timings;
    this.dataForm.seats=this.data.Seats;
    console.log(this.dataForm.seats)
    this.dataForm.price=this.data.Price;
  }

}
