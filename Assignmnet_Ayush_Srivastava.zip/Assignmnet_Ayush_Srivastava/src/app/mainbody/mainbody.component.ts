import { Component, OnInit } from '@angular/core';
import { TicketserviceService } from '../TicketService/ticketservice.service';

@Component({
  selector: 'app-mainbody',
  templateUrl: './mainbody.component.html',
  styleUrls: ['./mainbody.component.css']
})
export class MainbodyComponent implements OnInit {

  arr:any=[];
  init:boolean=true;
  constructor(private dataobj:TicketserviceService) { }

  ngOnInit(): void {
    this.dataobj.getMovieDetail().subscribe((data:any) => {
      this.arr = data;
     if(this.arr.length > 0)
      this.init = false;
    });
  }

}
