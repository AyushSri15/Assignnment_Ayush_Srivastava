import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { TicketData } from '../Utilites/TicketData';

@Injectable({
  providedIn: 'root'
})
export class PostdataService {

  header={'content-type':'application/json'}

  constructor(private httpClient:HttpClient) { }

  datapost(data:any):Observable<TicketData[]>{
    return this.httpClient.post<TicketData[]>("https://63415f6c16ffb7e275cfc2a6.mockapi.io/DashboardData",JSON.stringify(data),{'headers':this.header})
    .pipe(retry(1),catchError(this.handleError));
  }

  getUserData():Observable<TicketData[]>{
    return this.httpClient.get<TicketData[]>("https://63415f6c16ffb7e275cfc2a6.mockapi.io/DashboardData")
    .pipe(retry(1),catchError(this.handleError));
  }

  putUserData(id:string,body:any):Observable<any>{
    console.log(body)
    return this.httpClient.put<any>(`https://63415f6c16ffb7e275cfc2a6.mockapi.io/DashboardData/${id}`,body)
    .pipe(retry(1),catchError(this.handleError));
  }

  handleError(er:any){
    return throwError(()=>{
      console.log((er))
    })
  }

}




