import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offerspage',
  templateUrl: './offerspage.component.html',
  styleUrls: ['./offerspage.component.css']
})
export class OfferspageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
