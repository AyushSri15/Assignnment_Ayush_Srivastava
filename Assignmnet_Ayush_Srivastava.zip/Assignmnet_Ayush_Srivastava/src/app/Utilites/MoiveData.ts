export class MoiveData {
  id: number = 0;
  Movie_name: String = '';
  Seats: any = [];
  Timings: any = [];
  Ratings: number = 0;
  Image: String = '';
  Price: any = [];
  Description: String = '';
  Genre: String = '';
  Language: String = '';
  Origin: String = '';
  Trailer: String = '';
}
