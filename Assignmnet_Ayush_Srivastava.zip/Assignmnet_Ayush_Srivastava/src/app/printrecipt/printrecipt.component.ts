import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PostdataService } from '../TicketService/postdata.service';
import { TicketserviceService } from '../TicketService/ticketservice.service';
import { TicketData } from '../Utilites/TicketData';

@Component({
  selector: 'app-printrecipt',
  templateUrl: './printrecipt.component.html',
  styleUrls: ['./printrecipt.component.css'],
})
export class PrintreciptComponent implements OnInit {
  product: any;
  data: any;
  body: any = [];

  constructor(
    private object: Router,
    private moivedataobj: TicketserviceService,
    private postdataobj: PostdataService
  ) {
    this.product = this.object.getCurrentNavigation()?.extras.state;
    this.data = this.product.data;
    this.body = [this.data.seats[0], this.data.seats[1], this.data.seats[2]];
    this.body[this.data.timingIndex] = this.data.ticketsavl;
    this.data.seats[this.data.timingIndex] = this.data.ticketsavl;
    console.log(this.data);
  }

  ngOnInit(): void {
    console.log(this.data.moiveid);
    console.log(this.body);
    this.moivedataobj
      .updatedata(this.body, this.data.moiveid)
      .subscribe((data: any) => {
        console.log(data);
      });
    this.postdataobj.datapost(this.data).subscribe((data: TicketData[]) => {
      console.log(data);
    });
  }
}
