import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactComponent } from './contact/contact.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import { MainbodyComponent } from './mainbody/mainbody.component';
import { OfferspageComponent } from './offerspage/offerspage.component';
import { PrintreciptComponent } from './printrecipt/printrecipt.component';
import { SeatbookingComponent } from './seatbooking/seatbooking.component';

const routes: Routes = [
  { path: '', component: MainbodyComponent },
  { path: 'bookTicket/:id', component: SeatbookingComponent },
  { path: 'submit', component: PrintreciptComponent },
  { path: 'offers', component: OfferspageComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'dashboard', component: DashboardComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
